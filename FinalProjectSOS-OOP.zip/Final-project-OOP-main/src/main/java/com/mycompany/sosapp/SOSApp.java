package com.mycompany.sosapp;

/**
 *
 * @author calva
 */
public class SOSApp {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
